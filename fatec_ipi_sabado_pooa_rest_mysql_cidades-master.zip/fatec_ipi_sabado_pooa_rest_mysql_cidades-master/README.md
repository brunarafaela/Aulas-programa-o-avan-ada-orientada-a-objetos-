# Exercício Aula 3 (aula 4 no material) de Spring Boot MVC - REST + MySQL - Cidades

Criação de projeto utilizando o Spring InitializrCida

Criar Classe Cidades e oferecer os seguintes serviços REST

- Listar todas as cidades
- Listar todas as cidades cujo nome começa com uma letra específica
- Obter uma cidade por sua latitude e longitude
- Cadastrar novas cidades

Bibliotecas utilizadas

- DevTools 
- JPA 
- MySQL
- Web

Disciplina: Programação Avançada Orientada a Objetos do curso de ADS

