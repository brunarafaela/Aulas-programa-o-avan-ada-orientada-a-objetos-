# Aula 1 de Spring Boot MVC - Introdução
Criando um projeto Maven com o Spring Boot
Bibliotecas utilizadas 
- DevTools (para valores de configuração padronizados, restart automático, LiveReload (Refreshno navegador automático etc)
- Web (Inclui o Tomcat e a implementação do Spring)
- H2 ( um banco de dados na memória, somente para alguns testes iniciais)
- JPA (Java Persistence API, para fazer operações de persistência sem ter de escrever código JDBC diretamente)
- Thymeleaf (Biblioteca de TAGS para a camada de visualização. Uma boa alternativa ao uso de JSPs)

Disciplina: Programação Avançada Orientada a Objetos do curso de ADS
