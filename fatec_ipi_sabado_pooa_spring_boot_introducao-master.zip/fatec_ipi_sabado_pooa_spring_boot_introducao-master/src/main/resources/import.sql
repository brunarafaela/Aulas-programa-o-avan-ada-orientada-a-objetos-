INSERT INTO aluno (id, nome, media_notas) VALUES (1, 'Ana', 10);
INSERT INTO aluno (id, nome, media_notas) VALUES (2, 'José', 7);
INSERT INTO aluno (id, nome, media_notas) VALUES (3, 'Maria', 8);