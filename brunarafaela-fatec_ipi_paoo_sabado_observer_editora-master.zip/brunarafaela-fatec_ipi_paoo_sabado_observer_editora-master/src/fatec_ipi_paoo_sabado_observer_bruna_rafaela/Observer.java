package fatec_ipi_paoo_sabado_observer_bruna_rafaela;

public interface Observer {
	public void update (Entregavel e);
	public void setAssinatura (String a);
	public String getAssinatura ();
}
