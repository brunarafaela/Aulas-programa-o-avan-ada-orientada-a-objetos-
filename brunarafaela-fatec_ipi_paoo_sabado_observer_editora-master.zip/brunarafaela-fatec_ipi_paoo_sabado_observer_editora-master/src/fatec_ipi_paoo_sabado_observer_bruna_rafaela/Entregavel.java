package fatec_ipi_paoo_sabado_observer_bruna_rafaela;

public class Entregavel {
	public String conteudo;
}
