package fatec_ipi_pooa_sabado_strategy;

public interface FlyBehavior {
 	public  void fly();
	
}
