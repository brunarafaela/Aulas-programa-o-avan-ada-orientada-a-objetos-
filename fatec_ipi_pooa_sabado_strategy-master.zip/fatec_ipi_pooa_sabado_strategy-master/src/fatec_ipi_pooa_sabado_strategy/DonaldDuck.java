package fatec_ipi_pooa_sabado_strategy;

public class DonaldDuck extends Duck {

	@Override
	public void display() {
		System.out.println("Donald Duck");

	}

}
