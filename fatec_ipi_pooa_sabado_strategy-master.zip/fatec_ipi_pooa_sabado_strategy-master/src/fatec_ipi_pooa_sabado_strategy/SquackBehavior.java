package fatec_ipi_pooa_sabado_strategy;

public class SquackBehavior implements QuackBehavior {
 	public  void quack() {
		System.out.println("Squeak");
	}
}
