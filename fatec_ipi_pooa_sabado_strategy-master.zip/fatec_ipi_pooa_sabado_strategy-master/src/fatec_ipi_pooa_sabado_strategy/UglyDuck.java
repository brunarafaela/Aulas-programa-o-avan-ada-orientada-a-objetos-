package fatec_ipi_pooa_sabado_strategy;

public class UglyDuck extends Duck {

	@Override
	public void display() {
		System.out.println("Ugly Duck");

	}

}
