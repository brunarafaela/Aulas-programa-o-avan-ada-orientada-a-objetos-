package fatec_ipi_pooa_sabado_strategy;

public class FlyWithRocket implements FlyBehavior {

	@Override
	public  void fly() {
		System.out.println("I'm flyyyyyyyyyyingggg");
	}
	
}
