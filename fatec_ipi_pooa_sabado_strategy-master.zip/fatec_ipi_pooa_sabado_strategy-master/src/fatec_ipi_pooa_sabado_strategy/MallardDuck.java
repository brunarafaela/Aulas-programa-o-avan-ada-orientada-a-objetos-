package fatec_ipi_pooa_sabado_strategy;

public class MallardDuck extends Duck {

	@Override
	public void display() {
		System.out.println("Mallard Duck");
		
	}

}
