package fatec_ipi_pooa_sabado_strategy;

public class RegularQuackBehavior implements QuackBehavior{

	public  void quack() {
		System.out.println("quack");
	}
}