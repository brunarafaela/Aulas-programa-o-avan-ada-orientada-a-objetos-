module fatec_ipi_pooa_sabado_strategy {
}