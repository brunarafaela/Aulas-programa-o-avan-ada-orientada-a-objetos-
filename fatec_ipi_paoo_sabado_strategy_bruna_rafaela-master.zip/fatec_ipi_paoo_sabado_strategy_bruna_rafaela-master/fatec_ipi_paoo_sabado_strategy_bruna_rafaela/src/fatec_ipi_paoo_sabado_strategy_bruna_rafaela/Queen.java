package fatec_ipi_paoo_sabado_strategy_bruna_rafaela;

public class Queen extends Character {
	
	public Queen() {
		this.weapon = new BowAndArrowBehavior();
	}
}
