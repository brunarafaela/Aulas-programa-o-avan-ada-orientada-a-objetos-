package fatec_ipi_paoo_sabado_strategy_bruna_rafaela;

public class Knight extends Character {
	
	public Knight() {
		this.weapon = new AxeBehavior();
	}

}
