package fatec_ipi_paoo_sabado_strategy_bruna_rafaela;

public class King extends Character {

	public King() {
		this.weapon = new KnifeBehavior();
	}

}

