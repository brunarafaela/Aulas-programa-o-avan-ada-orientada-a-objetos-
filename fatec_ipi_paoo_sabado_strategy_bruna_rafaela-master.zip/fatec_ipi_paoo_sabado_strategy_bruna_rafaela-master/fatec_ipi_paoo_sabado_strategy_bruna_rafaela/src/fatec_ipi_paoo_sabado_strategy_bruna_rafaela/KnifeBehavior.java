package fatec_ipi_paoo_sabado_strategy_bruna_rafaela;

public class KnifeBehavior implements WeaponBehavior {

	@Override
	public void useWeapon() {
		System.out.println("Cutting with a knife");
	}
}
