package fatec_ipi_paoo_sabado_strategy_bruna_rafaela;

public class Troll extends Character {

	public Troll() {
		this.weapon = new AxeBehavior();
	}

}
