package fatec_ipi_paoo_sabado_strategy_bruna_rafaela;

public class BowAndArrowBehavior implements WeaponBehavior {

	@Override
	public void useWeapon() {
		System.out.println("Shooting an arrow with a bow");
	}
	
}
