package fatec_ipi_paoo_sabado_strategy_bruna_rafaela;

public class AxeBehavior implements WeaponBehavior {
	
	@Override
	public void useWeapon() {
		System.out.println("Chopping with an axe");
	}
}
