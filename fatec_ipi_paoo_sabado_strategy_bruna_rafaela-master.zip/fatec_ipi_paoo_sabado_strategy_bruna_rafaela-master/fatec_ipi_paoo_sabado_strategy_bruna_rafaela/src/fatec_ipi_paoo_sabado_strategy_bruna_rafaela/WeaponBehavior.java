package fatec_ipi_paoo_sabado_strategy_bruna_rafaela;

public interface WeaponBehavior {
	public void useWeapon();
	}
