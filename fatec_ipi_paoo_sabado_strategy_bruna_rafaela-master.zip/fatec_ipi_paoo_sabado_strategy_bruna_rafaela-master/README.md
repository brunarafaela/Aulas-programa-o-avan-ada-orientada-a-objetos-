# fatec_ipi_paoo_sabado_strategy_bruna_rafaela
exercício de strategy - some random game
