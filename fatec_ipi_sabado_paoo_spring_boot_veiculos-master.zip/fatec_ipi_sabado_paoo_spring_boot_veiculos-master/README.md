#  Exercício da aula 1 - Introducão ao Spring Boot e Spring MVC 

Projeto com Spring Boot utilizando as mesmas bibliotecas da aula
- Criar uma classe para representar um veículo (id, modelo, marca, ano de fabricação e cor), repositório no Spring Data e um controller

 Disciplina: Programação Avançada Orientada a Objetos do curso de ADS
