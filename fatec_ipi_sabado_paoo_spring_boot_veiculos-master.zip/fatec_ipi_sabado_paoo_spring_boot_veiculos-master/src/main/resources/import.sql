INSERT INTO veiculo (id, modelo, marca, ano, cor) VALUES (10, 'Fusca', 'Volkswagen', 1970, 'verde');
INSERT INTO veiculo (id, modelo, marca, ano, cor) VALUES (20, 'Porsche', 'Volkswagen', 2020, 'amarelo');
