package fatec_ipi_pooa_sabado_observer_animais;

public interface Observer {
	public void update (int n);
}
