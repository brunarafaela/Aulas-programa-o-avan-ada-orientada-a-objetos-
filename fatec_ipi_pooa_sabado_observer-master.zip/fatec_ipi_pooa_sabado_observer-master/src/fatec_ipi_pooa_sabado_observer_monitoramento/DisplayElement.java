package fatec_ipi_pooa_sabado_observer_monitoramento;

public interface DisplayElement {
	public void display();
	}