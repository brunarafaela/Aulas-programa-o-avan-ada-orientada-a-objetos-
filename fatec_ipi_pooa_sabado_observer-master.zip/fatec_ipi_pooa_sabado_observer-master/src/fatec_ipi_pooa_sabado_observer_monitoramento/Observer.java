package fatec_ipi_pooa_sabado_observer_monitoramento;

public interface Observer {
		public void update (double t, double h, double p); 
}
