package fatec_ipi_pooa_sabado_decorator;

public class HouseBlend extends Beverage {

	@Override
	public double cost() {
		return 8.5;
	}

}
