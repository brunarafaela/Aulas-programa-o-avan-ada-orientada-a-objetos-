package fatec_ipi_pooa_sabado_decorator;

public class Decaf extends Beverage {

	@Override
	public double cost() {
		return 4.5;
	}

}
