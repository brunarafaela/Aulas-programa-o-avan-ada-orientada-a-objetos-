package fatec_ipi_pooa_sabado_decorator;


public class DarkRoast extends Beverage {

	@Override
	public double cost() {
		return 7.9;
	}

}
