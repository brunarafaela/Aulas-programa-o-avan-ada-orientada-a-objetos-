INSERT INTO usuario (id, login, senha) VALUES (1, 'admin',  'admin');
INSERT INTO usuario (id, login, senha) VALUES (2, 'bruna', 'qwertyuiop');