package fatec_ipi_paoo_sabado_decorator_figuras;

public class Circulo extends Figura{

	@Override
	public void desenhar() {
		System.out.println("Circulo");
	}
}