package fatec_ipi_paoo_sabado_decorator_figuras;

public abstract class Figura {
	
	public abstract void desenhar();
	
}