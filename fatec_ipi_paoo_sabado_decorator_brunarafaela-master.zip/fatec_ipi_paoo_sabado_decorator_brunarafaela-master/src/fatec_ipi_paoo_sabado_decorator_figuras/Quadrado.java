package fatec_ipi_paoo_sabado_decorator_figuras;

public class Quadrado extends Figura {

	@Override
	public void desenhar() {
		System.out.println("Quadrado");
	}
}
