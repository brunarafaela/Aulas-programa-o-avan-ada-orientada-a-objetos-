# Aula 3 (4 no material) de Spring Boot MVC - REST + MySQL
Criação de projeto utilizando o Spring Initializr

Bibliotecas utilizadas

- DevTools
- JPA
- MySQL
- Web

Disciplina: Programação Avançada Orientada a Objetos do curso de ADS

