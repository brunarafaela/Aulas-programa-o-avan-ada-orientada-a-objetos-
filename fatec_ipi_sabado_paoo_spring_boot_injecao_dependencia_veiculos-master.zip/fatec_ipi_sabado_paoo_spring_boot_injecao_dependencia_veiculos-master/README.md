# Exercício da aula 2 - Spring Boot e Spring MVC - Injeção de dependência 

- Ajustar a atividade #1 Veículos para para fazer uso de injeção de dependência, incluindo as camadas de persistência, serviço e controllers
- Criar uma classe Calculadora para calcular a autonomia do veículo (adicionar novos atributos capacidade do tanque e rendimento por KM)

Disciplina: Programação Avançada Orientada a Objetos do curso de ADS
