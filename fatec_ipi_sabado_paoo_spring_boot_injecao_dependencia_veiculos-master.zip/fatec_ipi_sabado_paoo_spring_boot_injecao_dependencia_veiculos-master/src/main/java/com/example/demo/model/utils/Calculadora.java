package com.example.demo.model.utils;

public class Calculadora {
	
	public double Autonomia  (double tanque, double medida) {
		return tanque / medida; 
	}
	
}
