INSERT INTO usuario (id, login, senha) VALUES (300, 'admin',  'admin');
INSERT INTO usuario (id, login, senha) VALUES (400, 'bruna', 'qwertyuiop');