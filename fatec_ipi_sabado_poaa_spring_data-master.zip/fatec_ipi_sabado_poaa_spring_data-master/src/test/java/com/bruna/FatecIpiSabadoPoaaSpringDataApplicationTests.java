package com.bruna;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FatecIpiSabadoPoaaSpringDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
